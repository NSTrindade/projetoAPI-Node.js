const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Business = require('../models/Business');

// Create new business
router.post('/', auth, async (req, res) => {
  try {
    if (req.user.role !== 'business') {
      return res.status(403).json({ message: 'Only business users can create business profiles' });
    }

    const business = new Business({
      ...req.body,
      owner: req.user._id
    });

    await business.save();
    res.status(201).json(business);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get all businesses
router.get('/', async (req, res) => {
  try {
    const { category, neighborhood } = req.query;
    let query = {};

    if (category) query.category = category;
    if (neighborhood) query['address.neighborhood'] = neighborhood;

    const businesses = await Business.find(query)
      .populate('owner', 'name email')
      .sort({ createdAt: -1 });

    res.json(businesses);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get business by ID
router.get('/:id', async (req, res) => {
  try {
    const business = await Business.findById(req.params.id)
      .populate('owner', 'name email');

    if (!business) {
      return res.status(404).json({ message: 'Business not found' });
    }

    res.json(business);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Update business
router.put('/:id', auth, async (req, res) => {
  try {
    const business = await Business.findById(req.params.id);

    if (!business) {
      return res.status(404).json({ message: 'Business not found' });
    }

    if (business.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    const updatedBusiness = await Business.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { new: true }
    );

    res.json(updatedBusiness);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete business
router.delete('/:id', auth, async (req, res) => {
  try {
    const business = await Business.findById(req.params.id);

    if (!business) {
      return res.status(404).json({ message: 'Business not found' });
    }

    if (business.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    await business.remove();
    res.json({ message: 'Business removed' });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Search businesses by location
router.get('/search/location', async (req, res) => {
  try {
    const { longitude, latitude, maxDistance = 5000 } = req.query;

    if (!longitude || !latitude) {
      return res.status(400).json({ message: 'Longitude and latitude are required' });
    }

    const businesses = await Business.find({
      location: {
        $near: {
          $geometry: {
            type: 'Point',
            coordinates: [parseFloat(longitude), parseFloat(latitude)]
          },
          $maxDistance: parseInt(maxDistance)
        }
      }
    }).populate('owner', 'name email');

    res.json(businesses);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router; 