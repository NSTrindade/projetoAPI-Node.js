const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Business = require('./Business');

const Post = sequelize.define('Post', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  type: {
    type: DataTypes.ENUM('news', 'offer'),
    allowNull: false
  },
  title: {
    type: DataTypes.STRING,
    allowNull: false
  },
  content: {
    type: DataTypes.TEXT,
    allowNull: false
  },
  image: {
    type: DataTypes.STRING
  }
});

// Definindo relacionamentos
Post.belongsTo(Business, { foreignKey: 'businessId' });
Business.hasMany(Post, { foreignKey: 'businessId' });

module.exports = Post; 